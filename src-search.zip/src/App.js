import React from 'react';
import './App.css';

import SearchBar from './Searchbar';

class App extends React.Component  {
  // constructor(props){
  //     super(props);
  //     this.state = { images: [] };
  
  // }
  //     onSearchSubmit = async (e) => {
  // const response = await axios.get('https://api.unsplash.com/search/photos', {
  //             params: { query: e.target.value },
  //             headers: {
  //                 Authorization: 'Client-ID bf496bec0e70db4778b89474e258af494c21db3f5620f171aed37260a9863252'
  //             }
  //         })
  //         this.setState({ images: response.data.results })
  //     }
  
      render() {
          return (
              <div>
                <SearchBar  />
                  {/* Images Search Box : 
                  <input
                          className="inputStyle"
                          type="text"
                          onChange={this.onSearchSubmit}
                      /> */}
                      
                 
              </div>
          )
      }
  
  }
  export default App;